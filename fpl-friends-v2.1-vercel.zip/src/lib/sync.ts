import { prisma } from "./prisma";
import {
  currentGameweek,
  getBootstrap,
  getEntryHistory,
  getEntryTransfers,
  getLeagueStandings,
} from "./fpl";

export async function syncLeague(leagueId: number) {
  const bootstrap = await getBootstrap();
  const first = await getLeagueStandings(leagueId, 1);
  let standings = [...first.standings.results];
  let page = 1;

  while (first.standings.has_next && page < 20) {
    page += 1;
    const next = await getLeagueStandings(leagueId, page);
    standings.push(...next.standings.results);
    if (!next.standings.has_next) break;
  }

  await prisma.league.upsert({
    where: { id: leagueId },
    create: { id: leagueId, name: first.league.name },
    update: { name: first.league.name },
  });

  for (const s of standings) {
    const manager = await prisma.manager.upsert({
      where: { id: s.entry },
      create: {
        id: s.entry,
        leagueId,
        teamName: s.entry_name,
        managerName: s.player_name,
        totalPoints: s.total,
        currentRank: s.rank,
      },
      update: {
        leagueId,
        teamName: s.entry_name,
        managerName: s.player_name,
        totalPoints: s.total,
        currentRank: s.rank,
      },
    });

    const history = await getEntryHistory(manager.id);
    for (const h of history.current) {
      await prisma.managerGameweek.upsert({
        where: { managerId_gameweek: { managerId: manager.id, gameweek: h.event } },
        create: {
          managerId: manager.id,
          gameweek: h.event,
          points: h.points,
          totalPoints: h.total_points,
          rank: h.rank ?? null,
          overallRank: h.overall_rank ?? null,
          teamValue: h.value ?? null,
          bank: h.bank ?? null,
          transfers: h.event_transfers ?? null,
          transferCost: h.event_transfers_cost ?? null,
        },
        update: {
          points: h.points,
          totalPoints: h.total_points,
          rank: h.rank ?? null,
          overallRank: h.overall_rank ?? null,
          teamValue: h.value ?? null,
          bank: h.bank ?? null,
          transfers: h.event_transfers ?? null,
          transferCost: h.event_transfers_cost ?? null,
        },
      });
    }

    const transfers = await getEntryTransfers(manager.id);
    for (const t of transfers) {
      const existing = await prisma.transfer.findFirst({
        where: {
          managerId: manager.id,
          gameweek: t.event,
          playerIn: t.element_in,
          playerOut: t.element_out,
        },
      });
      if (!existing) {
        await prisma.transfer.create({
          data: {
            managerId: manager.id,
            gameweek: t.event,
            playerIn: t.element_in,
            playerOut: t.element_out,
            cost: t.cost,
            occurredAt: new Date(t.time),
          },
        });
      }
    }
  }

  for (const p of bootstrap.elements) {
    await prisma.playerSnapshot.upsert({
      where: { leagueId_playerId: { leagueId, playerId: p.id } },
      create: {
        leagueId, playerId: p.id, webName: p.web_name,
        firstName: p.first_name, secondName: p.second_name, teamId: p.team,
        elementType: p.element_type, nowCost: p.now_cost, totalPoints: p.total_points,
        form: Number(p.form), pointsPerGame: Number(p.points_per_game),
        selectedByPercent: Number(p.selected_by_percent), minutes: p.minutes,
        goalsScored: p.goals_scored, assists: p.assists,
        expectedGoals: Number(p.expected_goals), expectedAssists: Number(p.expected_assists),
        expectedGoalInvolvements: p.expected_goal_involvements ? Number(p.expected_goal_involvements) : null,
        transfersInEvent: p.transfers_in_event, transfersOutEvent: p.transfers_out_event,
        status: p.status,
      },
      update: {
        webName: p.web_name, firstName: p.first_name, secondName: p.second_name,
        teamId: p.team, elementType: p.element_type, nowCost: p.now_cost,
        totalPoints: p.total_points, form: Number(p.form),
        pointsPerGame: Number(p.points_per_game), selectedByPercent: Number(p.selected_by_percent),
        minutes: p.minutes, goalsScored: p.goals_scored, assists: p.assists,
        expectedGoals: Number(p.expected_goals), expectedAssists: Number(p.expected_assists),
        expectedGoalInvolvements: p.expected_goal_involvements ? Number(p.expected_goal_involvements) : null,
        transfersInEvent: p.transfers_in_event, transfersOutEvent: p.transfers_out_event,
        status: p.status, syncedAt: new Date(),
      },
    });
  }

  await prisma.league.update({
    where: { id: leagueId },
    data: { lastSyncAt: new Date() },
  });

  return {
    leagueId,
    leagueName: first.league.name,
    managers: standings.length,
    players: bootstrap.elements.length,
    gameweek: currentGameweek(bootstrap),
    syncedAt: new Date().toISOString(),
  };
}
