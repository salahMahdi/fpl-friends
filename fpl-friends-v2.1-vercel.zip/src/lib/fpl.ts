const baseUrl =
  process.env.FPL_API_BASE_URL ?? "https://fantasy.premierleague.com/api";

const cache = new Map<string, { expires: number; data: unknown }>();

async function getJson<T>(path: string, ttlSeconds = 300): Promise<T> {
  const key = path;
  const cached = cache.get(key);
  if (cached && cached.expires > Date.now()) return cached.data as T;

  const res = await fetch(`${baseUrl}${path}`, {
    headers: { Accept: "application/json" },
    next: { revalidate: ttlSeconds },
  });

  if (!res.ok) throw new Error(`FPL API ${res.status} for ${path}`);
  const data = (await res.json()) as T;
  cache.set(key, { expires: Date.now() + ttlSeconds * 1000, data });
  return data;
}

export type FplElement = {
  id: number; web_name: string; first_name: string; second_name: string;
  team: number; element_type: number; now_cost: number; total_points: number;
  form: string; points_per_game: string; selected_by_percent: string;
  minutes: number; goals_scored: number; assists: number;
  expected_goals: string; expected_assists: string;
  expected_goal_involvements?: string; transfers_in_event: number;
  transfers_out_event: number; status: string;
};

export type FplBootstrap = {
  elements: FplElement[];
  teams: { id: number; name: string; short_name: string }[];
  events: { id: number; name: string; finished: boolean; is_current: boolean; is_next: boolean }[];
};

export type FplStanding = {
  id: number; entry: number; entry_name: string; player_name: string;
  rank: number; last_rank: number; rank_sort: number; total: number;
  event_total: number; league_entry?: { id: number };
};

export type FplStandingsResponse = {
  new_entries: unknown; last_updated_data: string;
  league: { id: number; name: string };
  standings: { has_next: boolean; page: number; results: FplStanding[] };
};

export type FplEntryHistory = {
  current: Array<{
    event: number; points: number; total_points: number; rank?: number;
    overall_rank?: number; value?: number; bank?: number;
    event_transfers?: number; event_transfers_cost?: number;
  }>;
  past: unknown[];
  chips: unknown[];
};

export type FplTransfer = {
  element_in: number; element_out: number; event: number; time: string; cost: number;
};

export async function getBootstrap() {
  return getJson<FplBootstrap>("/bootstrap-static/", 3600);
}
export async function getLeagueStandings(leagueId: number, page = 1) {
  return getJson<FplStandingsResponse>(
    `/leagues-classic/${leagueId}/standings/?page_standings=${page}`,
    300
  );
}
export async function getEntryHistory(entryId: number) {
  return getJson<FplEntryHistory>(`/entry/${entryId}/history/`, 600);
}
export async function getEntryTransfers(entryId: number) {
  return getJson<FplTransfer[]>(`/entry/${entryId}/transfers/`, 600);
}
export function currentGameweek(bootstrap: FplBootstrap) {
  return bootstrap.events.find((e) => e.is_current)?.id
    ?? bootstrap.events.find((e) => e.is_next)?.id
    ?? Math.max(...bootstrap.events.map((e) => e.id));
}
