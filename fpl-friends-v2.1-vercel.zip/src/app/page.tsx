import Link from "next/link";

export default function Home() {
  const leagueId = process.env.FPL_LEAGUE_ID ?? "";
  return (
    <main style={{maxWidth: 1000, margin: "40px auto", padding: 24, fontFamily: "system-ui"}}>
      <h1>FPL Friends</h1>
      <p>Dashboard privé pour analyser une ligue Fantasy Premier League.</p>
      <ul>
        <li>Classement et évolution par journée</li>
        <li>Managers, points, transferts et historique</li>
        <li>Base joueurs pour le futur conseiller de transferts</li>
        <li>Synchronisation automatique toutes les heures</li>
      </ul>
      {leagueId ? (
        <Link href={`/league?leagueId=${leagueId}`}>Ouvrir ma ligue →</Link>
      ) : (
        <p>Configure <code>FPL_LEAGUE_ID</code> dans Vercel.</p>
      )}
    </main>
  );
}
