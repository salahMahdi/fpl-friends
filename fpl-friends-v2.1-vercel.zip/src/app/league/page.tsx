use client";

import { useEffect, useState } from "react";

type Manager = {
  id: number; teamName: string; managerName: string;
  totalPoints: number; currentRank: number;
};

export default function LeaguePage() {
  const [data, setData] = useState<{name: string; lastSyncAt: string | null; managers: Manager[]} | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    const id = new URLSearchParams(window.location.search).get("leagueId");
    if (!id) { setError("leagueId manquant"); return; }
    fetch(`/api/league/${id}`)
      .then(async r => {
        const json = await r.json();
        if (!r.ok) throw new Error(json.error ?? "Erreur");
        return json;
      })
      .then(setData)
      .catch(e => setError(e.message));
  }, []);

  if (error) return <main style={{padding: 24}}><h1>FPL Friends</h1><p>{error}</p></main>;
  if (!data) return <main style={{padding: 24}}>Chargement…</main>;

  return (
    <main style={{maxWidth: 1000, margin: "40px auto", padding: 24, fontFamily: "system-ui"}}>
      <h1>{data.name}</h1>
      <p>Dernière synchro : {data.lastSyncAt ? new Date(data.lastSyncAt).toLocaleString("fr-FR") : "jamais"}</p>
      <table style={{width: "100%", borderCollapse: "collapse"}}>
        <thead><tr><th align="left">Rang</th><th align="left">Manager</th><th align="left">Équipe</th><th align="right">Points</th></tr></thead>
        <tbody>
          {data.managers.map(m => (
            <tr key={m.id}>
              <td>{m.currentRank}</td>
              <td>{m.managerName}</td>
              <td>{m.teamName}</td>
              <td align="right">{m.totalPoints}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </main>
  );
}
