import { NextRequest, NextResponse } from "next/server";
import { syncLeague } from "@/src/lib/sync";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const expected = process.env.CRON_SECRET;
  const auth = request.headers.get("authorization")?.replace("Bearer ", "");

  if (!expected || auth !== expected) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const raw = process.env.FPL_LEAGUE_ID;
  const leagueId = Number(raw);

  if (!Number.isInteger(leagueId) || leagueId <= 0) {
    return NextResponse.json({ error: "FPL_LEAGUE_ID is missing" }, { status: 500 });
  }

  try {
    return NextResponse.json(await syncLeague(leagueId));
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Cron sync failed" }, { status: 500 });
  }
}
