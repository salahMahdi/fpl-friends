import { NextRequest, NextResponse } from "next/server";
import { syncLeague } from "@/src/lib/sync";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  const expected = process.env.SYNC_SECRET;
  const auth = request.headers.get("authorization")?.replace("Bearer ", "");
  if (!expected || auth !== expected) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await request.json().catch(() => ({}));
  const leagueId = Number(body.leagueId ?? process.env.FPL_LEAGUE_ID);

  if (!Number.isInteger(leagueId) || leagueId <= 0) {
    return NextResponse.json({ error: "Invalid leagueId" }, { status: 400 });
  }

  try {
    return NextResponse.json(await syncLeague(leagueId));
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "FPL sync failed" }, { status: 500 });
  }
}
