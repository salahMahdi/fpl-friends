import { NextResponse } from "next/server";
import { prisma } from "@/src/lib/prisma";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const leagueId = Number(id);

  if (!Number.isInteger(leagueId)) {
    return NextResponse.json({ error: "Invalid league id" }, { status: 400 });
  }

  const league = await prisma.league.findUnique({
    where: { id: leagueId },
    include: {
      managers: {
        orderBy: { currentRank: "asc" },
        select: {
          id: true, teamName: true, managerName: true,
          totalPoints: true, currentRank: true,
        },
      },
    },
  });

  if (!league) {
    return NextResponse.json({ error: "League not synced yet" }, { status: 404 });
  }

  return NextResponse.json(league);
}
