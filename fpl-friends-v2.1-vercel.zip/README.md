# FPL Friends — V2.1 Vercel + Neon

Version prête pour un test hébergé avec **Vercel Hobby + Neon Free**.

## Ce qui change par rapport à V2

- PostgreSQL au lieu de SQLite.
- Prisma compatible avec une base Neon distante.
- Synchronisation FPL persistante.
- `/api/sync` protégé par `SYNC_SECRET`.
- `/api/cron/sync` protégé par `CRON_SECRET`.
- Cron Vercel toutes les heures.
- Snapshots joueurs persistés pour préparer le conseiller de transferts.
- Fixtures/préparation de données prévue dans le modèle.
- L'application peut être déployée depuis un dépôt GitHub sans modifier le code.

## Déploiement

### 1. Créer la base Neon

Créer un projet PostgreSQL gratuit sur Neon puis récupérer sa `DATABASE_URL`.

### 2. Créer un dépôt GitHub

Décompresser ce ZIP et pousser le contenu dans un dépôt GitHub privé.

### 3. Importer dans Vercel

Dans Vercel :
- Add New → Project
- Importer le dépôt GitHub
- Framework : Next.js détecté automatiquement
- Ajouter les variables d'environnement :

```text
DATABASE_URL=...
FPL_API_BASE_URL=https://fantasy.premierleague.com/api
FPL_CACHE_TTL_SECONDS=300
FPL_LEAGUE_ID=123456
SYNC_SECRET=une-valeur-secrete-longue
CRON_SECRET=une-autre-valeur-secrete-longue
```

Ne mets jamais ces secrets dans GitHub.

### 4. Initialiser la base

Après le premier déploiement, exécuter localement :

```bash
npm install
npx prisma generate
npx prisma db push
```

avec le même `DATABASE_URL` Neon dans l'environnement local.

Alternative pratique : utiliser Prisma Studio/local CLI avec la `DATABASE_URL` Neon.

### 5. Lancer la première synchronisation

Le endpoint manuel attend :

```http
POST /api/sync
Authorization: Bearer <SYNC_SECRET>
Content-Type: application/json

{"leagueId":123456}
```

Exemple curl :

```bash
curl -X POST "https://TON-DOMAINE.vercel.app/api/sync" \
  -H "Authorization: Bearer TON_SYNC_SECRET" \
  -H "Content-Type: application/json" \
  -d '{"leagueId":123456}'
```

Une fois la première synchro faite :

```text
https://TON-DOMAINE.vercel.app/league?leagueId=123456
```

### 6. Cron

`vercel.json` programme `/api/cron/sync` toutes les heures.

Le cron utilise `FPL_LEAGUE_ID` et `CRON_SECRET`.

## Important

Cette version est une base de test hébergée, pas encore une version SaaS finale.

À ajouter ensuite :
- classement historique par journée dans les graphiques ;
- picks et capitaines ;
- comparaison manager vs manager ;
- analyse des transferts ;
- calendrier/difficulté des fixtures ;
- conseiller de transferts complet ;
- recommandations personnalisées par budget et effectif ;
- authentification ;
- multi-ligues ;
- dashboard responsive plus travaillé.

## Limite du free hosting

Vercel Hobby est adapté à un test personnel/non commercial. Pour un produit commercial, il faudra revoir le plan d'hébergement.

## Sécurité

Ne partage jamais avec ChatGPT :
- mot de passe GitHub ;
- mot de passe Neon ;
- token Vercel ;
- secrets `SYNC_SECRET` / `CRON_SECRET`.

Tu peux partager uniquement les informations non secrètes comme l'ID de ligue et l'URL publique de l'application.
